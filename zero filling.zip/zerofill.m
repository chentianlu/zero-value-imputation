 function varargout = zerofill(varargin)
% ZEROFILL MATLAB code for zerofill.fig
%      ZEROFILL, by itself, creates a new ZEROFILL or raises the existing
%      singleton*.
%
%      H = ZEROFILL returns the handle to a new ZEROFILL or the handle to
%      the existing singleton*.
%
%      ZEROFILL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ZEROFILL.M with the given input arguments.
%
%      ZEROFILL('Property','Value',...) creates a new ZEROFILL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before zerofill_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to zerofill_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help zerofill

% Last Modified by GUIDE v2.5 25-Nov-2015 09:31:13

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @zerofill_OpeningFcn, ...
                   'gui_OutputFcn',  @zerofill_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before zerofill is made visible.
function zerofill_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to zerofill (see VARARGIN)

% Choose default command line output for zerofill
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes zerofill wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = zerofill_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Input.
function Input_Callback(hObject, eventdata, handles)
% hObject    handle to Input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[FileNamein,PathNamein] = uigetfile({'*.xls';'*.xlsx';'*.mat';'*.csv'},'File Import');
set(handles.InName,'string',[PathNamein,FileNamein]);

% --- Executes on button press in Output.
function Output_Callback(hObject, eventdata, handles)
% hObject    handle to Output (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[FileNameout,PathNameout] = uiputfile({'*.xls';'*.xlsx';'*.csv'},'File Export');
set(handles.OutName,'string',[PathNameout,FileNameout]);

% --- Executes on button press in Run.
function Run_Callback(hObject, eventdata, handles)
% hObject    handle to Run (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
switch get(handles.Method,'value')
case 1
filein=get(handles.InName,'string');
fileout=get(handles.OutName,'string');
data=xlsread(filein);
%excel_data_analysis:using matlab 
%note:this code must be in the same folder as data.xls,because relative
%directory is used here.
indexofdata=data(:,1);%indexofdata is the first column of the excel data,this matrix is to get the group number of the experiment.
max_group_number=max(indexofdata);%this data is used to get the max group number.
output=cell(180,60);%define a matrix to save the output data and then write into excell.


for i=1:max_group_number;%group 
    groupnumber=i;
    group_data_range=find(indexofdata==groupnumber);%this matrix is used to get the range of the index of one group.
    indexbegin=min(group_data_range);%find the min index
    indexend=max(group_data_range);%find the max index
    columnnumber=size(data,2);%get the column number
    for j=2:columnnumber;%sample of group
        tempmatrix=data(indexbegin:indexend,j);%find the data of one sample of one group
        indexofnozero=find(tempmatrix ~= 0);
        lgindexofnozero=size(indexofnozero,1);
        if lgindexofnozero==0;
            lgindexofnozero=1;
        end
       averagevalue=mean(tempmatrix(indexofnozero));
        indexofzero=find(tempmatrix==0);%find zero's index
        templength=size(indexofzero,1);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % use for loop to change the value of the zero data%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        for n=1:templength;%change zero data
            %tempmatrix(indexofzero(n))
            tempmatrix(indexofzero(n))=averagevalue;%change the zero number to mean value.
            %tempmatrix(indexofzero(n))%to test if the for loop works!
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %use for loop to write the changed data to the output matrix which
        %is used as output buffer%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        k=indexbegin;%you can never pay more attention to this!
        %size(tempmatrix,1)
        for m=1:size(tempmatrix,1);%output
            %tempmatrix(m)
            output{k,j}=tempmatrix(m);
            k=k+1;%you can never pay more attention to this!
        end
        
    end
end

for n=1:size(indexofdata,1);%this loop is used to write the group number to output matrix
    output{n,1}=indexofdata(n);
    data=output;
end


    case 2
filein=get(handles.InName,'string');
fileout=get(handles.OutName,'string');
data=xlsread(filein);
%excel_data_analysis:using matlab 
%note:this code must be in the same folder as data.xls,because relative
%directory is used here.
indexofdata=data(:,1);%indexofdata is the first column of the excel data,this matrix is to get the group number of the experiment.
max_group_number=max(indexofdata);%this data is used to get the max group number.
output=cell(180,60);%define a matrix to save the output data and then write into excell.


for i=1:max_group_number;%group 
    groupnumber=i;
    group_data_range=find(indexofdata==groupnumber);%this matrix is used to get the range of the index of one group.
    indexbegin=min(group_data_range);%find the min index
    indexend=max(group_data_range);%find the max index
    columnnumber=size(data,2);%get the column number
    for j=2:columnnumber;%sample of group
        tempmatrix=data(indexbegin:indexend,j);%find the data of one sample of one group
        indexofnozero=find(tempmatrix ~= 0);
        lgindexofnozero=size(indexofnozero,1);
        if lgindexofnozero==0;
            lgindexofnozero=1;
        end
        medianvalue=median(tempmatrix(indexofnozero));
        indexofzero=find(tempmatrix==0);%find zero's index
        templength=size(indexofzero,1);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % use for loop to change the value of the zero data%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        for n=1:templength;%change zero data
            %tempmatrix(indexofzero(n))
            tempmatrix(indexofzero(n))=medianvalue;%change the zero number to mean value.
            %tempmatrix(indexofzero(n))%to test if the for loop works!
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %use for loop to write the changed data to the output matrix which
        %is used as output buffer%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        k=indexbegin;%you can never pay more attention to this!
        %size(tempmatrix,1)
        for m=1:size(tempmatrix,1);%output
            %tempmatrix(m)
            output{k,j}=tempmatrix(m);
            k=k+1;%you can never pay more attention to this!
        end
        
    end
end

for n=1:size(indexofdata,1);%this loop is used to write the group number to output matrix
    output{n,1}=indexofdata(n);
    data=output;
end
case 3
filein=get(handles.InName,'string');
fileout=get(handles.OutName,'string');
data=xlsread(filein);
for i=1:size(data,2);
    [r,c]=find(data(:,i)==0);
    if(r)
        [r1,c1]=find(data(:,i)>0);
         data(r,i)=mean(data(r1,i));
    end
end
case 4
filein=get(handles.InName,'string');
fileout=get(handles.OutName,'string');
data=xlsread(filein);
for i=1:size(data,2);
    [r,c]=find(data(:,i)==0);
    if(r)
        [r1,c1]=find(data(:,i)>0);
         data(r,i)=median(data(r1,i));
    end
end
case 5
filein=get(handles.InName,'string');
fileout=get(handles.OutName,'string');
data=xlsread(filein);
for i=1:size(data,2);
    [r,c]=find(data(:,i)==0);
    if(r)
        [r1,c1]=find(data(:,i)>0);
         data(r,i)=(min(data(r1,i)));
    end
end
case 6
filein=get(handles.InName,'string');
fileout=get(handles.OutName,'string');
data=xlsread(filein);
   for i=1:size(data,2);
    [r,c]=find(data(:,i)==0);
    if(r)
        [r1,c1]=find(data(:,i)>0);
         data(r,i)=(mean(data(r1,i)))*1/10;
  end
 end
        
case 7
filein=get(handles.InName,'string');
fileout=get(handles.OutName,'string');
data=xlsread(filein);
%excel_data_analysis:using matlab 
%note:this code must be in the same folder as data.xls,because relative
%directory is used here.
indexofdata=data(:,1);%indexofdata is the first column of the excel data,this matrix is to get the group number of the experiment.
max_group_number=max(indexofdata);%this data is used to get the max group number.
output=cell(180,60);%define a matrix to save the output data and then write into excell.


for i=1:max_group_number;%group 
    groupnumber=i;
    group_data_range=find(indexofdata==groupnumber);%this matrix is used to get the range of the index of one group.
    indexbegin=min(group_data_range);%find the min index
    indexend=max(group_data_range);%find the max index
    columnnumber=size(data,2);%get the column number
    for j=2:columnnumber;%sample of group
        tempmatrix=data(indexbegin:indexend,j);%find the data of one sample of one group
        indexofnozero=find(tempmatrix ~= 0);
        lgindexofnozero=size(indexofnozero,1);
        if lgindexofnozero==0;
            lgindexofnozero=1;
        end
        minvalue=min(tempmatrix(indexofnozero));
        indexofzero=find(tempmatrix==0);%find zero's index
        templength=size(indexofzero,1);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % use for loop to change the value of the zero data%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        for n=1:templength;%change zero data
            %tempmatrix(indexofzero(n))
            tempmatrix(indexofzero(n))=minvalue;%change the zero number to mean value.
            %tempmatrix(indexofzero(n))%to test if the for loop works!
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %use for loop to write the changed data to the output matrix which
        %is used as output buffer%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        k=indexbegin;%you can never pay more attention to this!
        %size(tempmatrix,1)
        for m=1:size(tempmatrix,1);%output
            %tempmatrix(m)
            output{k,j}=tempmatrix(m);
            k=k+1;%you can never pay more attention to this!
        end
        
    end
end

for n=1:size(indexofdata,1);%this loop is used to write the group number to output matrix
    output{n,1}=indexofdata(n);
    data=output;
end
   
case 8
filein=get(handles.InName,'string');
fileout=get(handles.OutName,'string');
data=xlsread(filein);
%excel_data_analysis:using matlab 
%note:this code must be in the same folder as data.xls,because relative
%directory is used here.
indexofdata=data(:,1);%indexofdata is the first column of the excel data,this matrix is to get the group number of the experiment.
max_group_number=max(indexofdata);%this data is used to get the max group number.
output=cell(180,60);%define a matrix to save the output data and then write into excell.


for i=1:max_group_number;%group 
    groupnumber=i;
    group_data_range=find(indexofdata==groupnumber);%this matrix is used to get the range of the index of one group.
    indexbegin=min(group_data_range);%find the min index
    indexend=max(group_data_range);%find the max index
    columnnumber=size(data,2);%get the column number
    for j=2:columnnumber;%sample of group
        tempmatrix=data(indexbegin:indexend,j);%find the data of one sample of one group
        indexofnozero=find(tempmatrix ~= 0);
        lgindexofnozero=size(indexofnozero,1);
        if lgindexofnozero==0;
            lgindexofnozero=1;
        end
        tenthminvalue=(min(tempmatrix(indexofnozero)))*1/10;
        indexofzero=find(tempmatrix==0);%find zero's index
        templength=size(indexofzero,1);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % use for loop to change the value of the zero data%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        for n=1:templength;%change zero data
            %tempmatrix(indexofzero(n))
            tempmatrix(indexofzero(n))=tenthminvalue;%change the zero number to mean value.
            %tempmatrix(indexofzero(n))%to test if the for loop works!
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %use for loop to write the changed data to the output matrix which
        %is used as output buffer%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        k=indexbegin;%you can never pay more attention to this!
        %size(tempmatrix,1)
        for m=1:size(tempmatrix,1);%output
            %tempmatrix(m)
            output{k,j}=tempmatrix(m);
            k=k+1;%you can never pay more attention to this!
        end
        
    end
end

for n=1:size(indexofdata,1);%this loop is used to write the group number to output matrix
    output{n,1}=indexofdata(n);
    data=output;
end
end
xlswrite(fileout,data);
waitfor(msgbox('finished!','done'));


% --- Executes on button press in Exit.
function Exit_Callback(hObject, eventdata, handles)
% hObject    handle to Exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close all;


% --- Executes during object creation, after setting all properties.
function axes2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes2


% --- Executes during object creation, after setting all properties.
function text4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on selection change in Method.
function Method_Callback(hObject, eventdata, handles)
% hObject    handle to Method (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Method contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Method



function OutName_Callback(hObject, eventdata, handles)
% hObject    handle to OutName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of OutName as text
%        str2double(get(hObject,'String')) returns contents of OutName as a double



function InName_Callback(hObject, eventdata, handles)
% hObject    handle to InName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of InName as text
%        str2double(get(hObject,'String')) returns contents of InName as a double


% --- Executes during object creation, after setting all properties.
function Method_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Method (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function InName_CreateFcn(hObject, eventdata, handles)
% hObject    handle to InName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function OutName_CreateFcn(hObject, eventdata, handles)
% hObject    handle to OutName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in zero.
function zero_Callback(hObject, eventdata, handles)
% hObject    handle to zero (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
filein=get(handles.InName,'string');
fileout=get(handles.OutName,'string');
data=xlsread(filein);
indexofdata=data(:,1);%indexofdata is the first column of the excel data,this matrix is to get the group number of the experiment.
max_group_number=max(indexofdata);%this data is used to get the max group number.
for i=1:max_group_number;
    groupnumber=i;
    group_data_range=find(indexofdata==groupnumber);%this matrix is used to get the range of the index of one group.
    indexbegin=min(group_data_range);%find the min index
    indexend=max(group_data_range);%find the max index
    columnnumber=size(data,2);%get the column number
    for j=2:columnnumber;
        tempmatrix=data(indexbegin:indexend,j);%find the data of one sample of one group
        indexofzero=find(tempmatrix==0);%find zero's index
        zeronumber=size(indexofzero,1);%calculate the number of index matrix number,this number is number of zero.
        outputs{i,j}=zeronumber;%write the output.
%         switch i;%use switch to check whicl excel unit to write, but this
%             case 1;
%                 switch j;
%                     case 2;
%                         %cell=strcat('''','B',i,'''')
%                         xlswrite(fileout,zeronumber,'sheet2','B1');
%                     case 3;
%                         %cell=strcat('''','C',i,'''')
%                         xlswrite(fileout,zeronumber,'sheet2','C1');
%                     case 4;
%                         %cell=strcat('''','D',i,'''')
%                         xlswrite(fileout,zeronumber,'sheet2','D1');
%                     case 5;
%                         %cell=strcat('''','E',i,'''')
%                         xlswrite(fileout,zeronumber,'sheet2','E1');
%                     case 5;
%                         %cell=strcat('''','F',i,'''')
%                         xlswrite(fileout,zeronumber,'sheet2','F1');  
%                     otherwise               
%                 end
%             case 2;
%                 switch j;
%                     case 2;
%                         %cell=strcat('''','B',i,'''')
%                         xlswrite(fileout,zeronumber,'sheet2','B2');
%                     case 3;
%                         %cell=strcat('''','C',i,'''')
%                         xlswrite(fileout,zeronumber,'sheet2','C2');
%                     case 4;
%                         %cell=strcat('''','D',i,'''')
%                         xlswrite(fileout,zeronumber,'sheet2','D2');
%                     case 5;
%                         %cell=strcat('''','E',i,'''')
%                         xlswrite(fileout,zeronumber,'sheet2','E2');
%                     case 5;
%                         %cell=strcat('''','F',i,'''')
%                         xlswrite(filepout,zeronumber,'sheet2','F2');  
%                     otherwise               
%                 end
%             case 3;
%                 switch j;
%                     case 2;
%                         %cell=strcat('''','B',i,'''')
%                         xlswrite(fileout,zeronumber,'sheet2','B3');
%                     case 3;
%                         %cell=strcat('''','C',i,'''')
%                         xlswrite(fileout,zeronumber,'sheet2','C3');
%                     case 4;
%                         %cell=strcat('''','D',i,'''')
%                         xlswrite(fileout,zeronumber,'sheet2','D3');
%                     case 5;
%                         %cell=strcat('''','E',i,'''')
%                         xlswrite(fileout,zeronumber,'sheet2','E3');
%                     case 5;
%                         %cell=strcat('''','F',i,'''')
%                         xlswrite(fileout,zeronumber,'sheet2','F3');  
%                     otherwise               
%                 end
%         end
    end
end
%output;
xlswrite(fileout,outputs,'sheet2');
waitfor(msgbox('finished!','done'));
